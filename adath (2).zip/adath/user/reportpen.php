<?php
include('../dbconnect.php');
$u = $_GET['u'];
$cekdulu = mysqli_query($conn,"select * from userdata where nisn='$u'");
    $ambil = mysqli_fetch_array($cekdulu);
    //get alamat
    $ambilprov = $ambil['provinsi'];
    $prov1 = mysqli_query($conn,"select name from provinces where id='$ambilprov'");
    $prov = mysqli_fetch_array($prov1)['name'];
    $ambilkota = $ambil['kabupaten'];
    $kab1 = mysqli_query($conn,"select name from regencies where id='$ambilkota'");
    $kab = mysqli_fetch_array($kab1)['name'];
    $ambilkec = $ambil['kecamatan'];
    $kec1 = mysqli_query($conn,"select name from districts where id='$ambilkec'");
    $kec = mysqli_fetch_array($kec1)['name'];
    $ambilkel = $ambil['kelurahan'];
    $kel1 = mysqli_query($conn,"select name from villages where id='$ambilkel'");
    $kel = mysqli_fetch_array($kel1)['name'];

require_once("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$query = mysqli_query($conn,"select * from userdata where nisn='$u'");
$html = '
<center><h3>Persyaratan Pendaftaran </h3></center><hr/><br/>';
$html .= '<div class="row mt-5 mb-5">
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-between align-items-center">
            <h2>Dokumen Pendaftaran</h2>
            <p>Tanda (*) harap diisi </p>
            </div>
            <div class="market-status-table mt-4">
                <div class="table-responsive" style="overflow-x:hidden;">
                    
                <div class="row">
                <div class="col">
                    <div class="form-group">
                            <label for="kartukeluarga" class=" form-control-label">Foto Kartu Keluarga* (JPG/PNG), maks 500kb</label>
                            <input type="file" id="kartukeluarga" name="kartukeluarga" class="form-control-file">
                     </div>
                </div>
                <div class="col">
                <div class="form-group">
                            <label for="rapor" class=" form-control-label">Foto Rapor*  (JPG/PNG), maks 500kb</label>
                            <input type="file" id="rapor" name="rapor" class="form-control-file">
                 </div>
                </div>
            </div>
            <div class="row">
            <div class="col">
                    <div class="form-group">
                            <label for="scanakte" class=" form-control-label">Scan Akte Lahir* (JPG/PNG), maks 500kb</label>
                            <input type="file" id="scanakte" name="scanakte" class="form-control-file">
                        </div>
                    </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="form-group">
                            <label for="scanijazahdepan" class=" form-control-label">Scan Ijazah Bagian Depan* (JPG/PNG), maks 500kb</label>
                            <input type="file" id="scanijazahdepan" name="scanijazahdepan" class="form-control-file">
                        </div>
                    </div>
                <div class="col">
                    <div class="form-group">
                            <label for="scanijazahbelakang" class=" form-control-label">Scan Ijazah Bagian Belakang* (JPG/PNG), maks 500kb</label>
                            <input type="file" id="scanijazahbelakang" name="scanijazahbelakang" class="form-control-file">
                    </div>
                </div>
            </div>

                <div class="modal-footer">
                    <input type="submit" name="submit" class="btn btn-primary" value="Simpan">
                </div>
        
            </div>
    </div>
</div>
</div>

                
                <!-- row area start-->
            </div>
        </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
</div>';

$html .= "</html>";
$dompdf->loadHtml($html);
// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
// Rendering dari HTML Ke PDF
$dompdf->render();
// Melakukan output file Pdf
$dompdf->stream($u.'.pdf');
?>
